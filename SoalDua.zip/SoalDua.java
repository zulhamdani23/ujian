package ujianeval1.eval1;

import java.util.Arrays;
import java.util.Scanner;

public class SoalDua {
	public static Scanner scan = new Scanner(System.in);

	public static int getInput() {
		System.out.print("Masukkan uang anda: ");
		int n = scan.nextInt();
		return n;
	}

	public static int[] getArray1() {
		System.out.println("Masukkan harga kaca mata");
		int[] kaca = new int[3];
		for (int i = 0; i < 3; i++) {
//			System.out.println("Harga kaca mata");
			System.out.print("Harga ke " + (i + 1) + ": ");
			int bil = scan.nextInt();
			kaca[i] = bil;
		}
		System.out.print("Harga kaca mata: " + Arrays.toString(kaca));
		System.out.println();
		return kaca;
	}

	public static int[] getArray2() {
		System.out.println("Masukkan harga baju");
		int[] baju = new int[3];
		for (int i = 0; i < 3; i++) {
//			System.out.println("Harga kaca mata");
			System.out.print("Harga ke " + (i + 1) + ": ");
			int bil = scan.nextInt();
			baju[i] = bil;
		}
		System.out.print("Harga baju: " + Arrays.toString(baju));
		System.out.println();
		return baju;
	}

	public void hitung() {
		int n = getInput();
		int[] kaca = getArray1();
		int[] baju = getArray2();
		int[] hasil = new int [9];
		int k=0;
//		boolean cek = false;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j<3; j++) {
//				hasil [] = (kaca[i]+baju[j]);
				System.out.println("hasil:"+ (kaca[i]+baju[j]));
//				System.out.println(hasil);
//				if ((kaca[i]+baju[j]) <=70) {
//					System.out.println("cukup");
//				} else {
//					System.out.println("cobalagi");
//				}
			}
			
		}
	}

	public static void main(String[] args) {
//		int n = getInput();
//		int[] baju = getArray1();
//		int[] kaca = getArray2();
		SoalDua run = new SoalDua();
		run.hitung();
	}

}
